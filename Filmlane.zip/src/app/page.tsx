import { ScreenplayEditor } from '@/components/editor';

export default function Home() {
  return <ScreenplayEditor />;
}

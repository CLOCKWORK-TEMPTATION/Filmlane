import { config } from 'dotenv';
config();

import '@/ai/flows/auto-format-screenplay.ts';
import '@/ai/flows/generate-scene-ideas.ts';